import { useState } from 'react';
import { useRef } from 'react';
import { useEffect } from "react";
import './App.css';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';

function App() {
  function BookList(props){
    useEffect( () => {
      var myHeaders = new Headers();
      var requestOptions = {
          method: 'GET',
          headers: myHeaders,
          redirect: 'follow'
      };
  
      fetch("http://localhost:8080/api/v1/books", requestOptions)
      .then(
          response =>  {
              if( !response.ok) {
                  let code = response.status.toString();
                  throw new Error( `${code} ${response.statusText}`);
              }
              return response.json();
      })
      .then( book => props.setInfo(book) )
      .catch( e => {
          console.log("Error!!!");
          console.log(e.message);
      });
      
    },[])
    return (
      <>
      {
          props.books.map( book => {
              return (
              <>
              <Container style={{ 
              backgroundColor: 'lightgrey',
              width: '50%',
              borderRadius: 10,}}>
              {/* <button onClick={() => deleteMovie(movie.name)}>Remove</button> */}
              <h2>{book.title}</h2>
              <h3>{book.isbn}</h3>
              <h3>{book.edition_number}</h3>
              <p>{book.copy_right}</p>
              <hr></hr>
              </Container>
              </>)
          })
      }  
  </>
    )
  }
  const [books, setBooks] = useState([]);
  return (
    <div className="App">
      <header className="App-header">
        <h1>Book List</h1>
        <BookList books={books} setInfo={setBooks}/>
      </header>
    </div>
  );
}

export default App;
